(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_next_dist_1n8s05di1tks4._.js","static/chunks/_1utiua6g6xlr0._.js","static/chunks/_0j0js8t6asaue._.css","static/chunks/_0vzzlpec3qyir._.js","static/chunks/styles_0-xpqz12j-m9e._.css"],
    source: "entry"
});
