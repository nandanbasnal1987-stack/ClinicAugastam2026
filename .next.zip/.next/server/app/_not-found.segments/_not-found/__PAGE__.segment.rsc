1:"$Sreact.fragment"
2:"/_next/static/chunks/2n9_9xd704-iy.js"
3:I[93983,["$2"],"default"]
4:I[39756,["$2"],"default"]
5:I[37457,["$2"],"default"]
:HL["/_next/static/chunks/2pgaa38k5lrz4.css","style"]
:HL["https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap","style"]
:HL["https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap","style"]
:HL["https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&family=Inter:wght@400;500;600;700&display=swap","style"]
:HL["https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&family=Inter:wght@400;500;600;700&display=swap","style"]
:HL["https://fonts.googleapis.com/css2?family=Lato:wght@400;700;900&family=Poppins:wght@400;500;600&display=swap","style"]
:HL["https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap","style"]
:HL["https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap","style"]
:HL["https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap","style"]
:HL["https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&family=Inter:wght@500;700&display=swap","style"]
:HL["https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap","style"]
:HL["https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,600;1,400&family=Roboto:wght@400;500&display=swap","style"]
a:X
e:X
e:C
f:[["children",{"s":"__PAGE__","h":160,"d":{"r":"$L10","p":"$@11","v":null,"s":"$a"}}]]
b:[["children",{"s":"/_not-found","h":96,"d":{"r":"$Lc","p":"$@d","v":"$e","s":"$a"},"c":"$Qf"}]]
0:{"t":{"t":{"s":"","h":80,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/2pgaa38k5lrz4.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/2n9_9xd704-iy.js","async":true}]],["$","html",null,{"lang":"en","suppressHydrationWarning":true,"children":[["$","head",null,{"children":[["$","link",null,{"rel":"preconnect","href":"https://fonts.googleapis.com"}],["$","link",null,{"rel":"preconnect","href":"https://fonts.gstatic.com","crossOrigin":"anonymous"}],[["$","link","https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap","rel":"stylesheet"}],["$","link","https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap","rel":"stylesheet"}],["$","link","https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&family=Inter:wght@400;500;600;700&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&family=Inter:wght@400;500;600;700&display=swap","rel":"stylesheet"}],["$","link","https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&family=Inter:wght@400;500;600;700&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&family=Inter:wght@400;500;600;700&display=swap","rel":"stylesheet"}],["$","link","https://fonts.googleapis.com/css2?family=Lato:wght@400;700;900&family=Poppins:wght@400;500;600&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Lato:wght@400;700;900&family=Poppins:wght@400;500;600&display=swap","rel":"stylesheet"}],["$","link","https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap","rel":"stylesheet"}],["$","link","https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap","rel":"stylesheet"}],["$","link","https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap","rel":"stylesheet"}],["$","link","https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&family=Inter:wght@500;700&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&family=Inter:wght@500;700&display=swap","rel":"stylesheet"}],["$","link","https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap","rel":"stylesheet"}],["$","link","https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,600;1,400&family=Roboto:wght@400;500&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,600;1,400&family=Roboto:wght@400;500&display=swap","rel":"stylesheet"}]]]}],["$","body",null,{"children":[["$","$L3",null,{}],["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}],"notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],"$L6","$L7"]}]}]],[]]}],"$L8"]}]]}]]}],"p":"$@9","v":null,"s":"$a"},"c":"$Qb"},"h":{"r":"$L12","p":"$@13","v":null,"s":"$a"}},"a":"$@14","u":"$@15","b":"DfoUAV7tUgkXy_fTRnuM-"}
16:I[87392,["$2"],"default"]
17:I[97367,["$2"],"OutletBoundary"]
18:"$Sreact.suspense"
1a:"ViewportBoundary"
1b:I[97367,["$2"],"$1a"]
1c:"MetadataBoundary"
1d:I[97367,["$2"],"$1c"]
6:["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}]
7:["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]
8:["$","$L16",null,{}]
c:["$","$1","c",{"children":[null,["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]]}]
10:["$","$1","c",{"children":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":"$0:t:t:d:r:props:children:1:props:children:1:props:children:1:props:notFound:0:1:props:style","children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":"$6:props:style","children":404}],["$","div",null,{"style":"$7:props:style","children":["$","h2",null,{"style":"$7:props:children:props:style","children":"This page could not be found."}]}]]}]}]],null,["$","$L17",null,{"children":["$","$18",null,{"name":"Next.MetadataOutlet","children":"$@19"}]}]]}]
12:["$","$1","h",{"children":[["$","meta",null,{"name":"robots","content":"noindex"}],["$","$L1b",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1, viewport-fit=cover"}]]}],["$","$L1d",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$18",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Augastam Clinical – AI-Native Clinical care"}],["$","meta","1",{"name":"description","content":"Smarter, connected healthcare with Augastam Clinical — bringing consultations, clinical documentation, and AI-powered tools together to support better patient care at every stage."}]]}]}],null]}],null]}]
19:null
15:true
a:300
a:C
14:0
d:"$undefined"
13:"$undefined"
11:"$undefined"
9:"$undefined"
